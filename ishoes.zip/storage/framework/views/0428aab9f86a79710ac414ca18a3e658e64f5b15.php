<?php
$menu = App\Menu::all()->toArray();
?>

<?php $__env->startSection('main_content'); ?>
<div id="content">
    <div class="container">
      <div id="error-page" class="col-md-8 mx-auto text-center">
        <div class="box">
          <h3>We are sorry - this page is not here anymore</h3>
          <h4 class="text-muted">Error 404 - Page not found</h4>
        <p class="buttons"><a href="<?php echo e(url('')); ?>" class="btn btn-template-outlined"><i class="fa fa-home"></i> Go to Homepage</a></p>
        </div>
      </div>
    </div>
  </div>
  <!-- GET IT-->
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/errors/404.blade.php ENDPATH**/ ?>