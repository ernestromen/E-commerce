<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Site Orders'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-12 mt-5">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#ID</th>
                    <th>User</th>
                    <th>Order</th>
                    <th>#ID</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($order->id); ?></td>
                <td><?php echo e($order->name); ?></td>
                <td>
                    <ul>
                        <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($item['name']); ?>, 
                        Quantity: <?php echo e($item['quantity']); ?>,
                        Price: $ <?php echo e($item['price']); ?>

                    </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </td>
                <td>$<?php echo e($order->total); ?></td>
                <td><?php echo e(date('d/m/Y H:i:s', strtotime($order->created_at))); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/orders.blade.php ENDPATH**/ ?>