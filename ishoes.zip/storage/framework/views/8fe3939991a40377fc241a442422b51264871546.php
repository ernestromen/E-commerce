<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col">
        <p>
        <a href="<?php echo e(url('cms/content/create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
               Add Content
            </a>
        </p>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Content title</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($content['ctitle']); ?></td>
                <td>
                <a href="<?php echo e(url('cms/content/' . $content['id'] . '/edit')); ?>">
                        <i class="far fa-edit"></i>
                        Edit</a>
                        |
                    <a href="<?php echo e(url('cms/content/' .$content['id'])); ?>">
                            <i class="fas fa-eraser"></i>
                            Delete</a>
                </td>
               
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/content_index.blade.php ENDPATH**/ ?>