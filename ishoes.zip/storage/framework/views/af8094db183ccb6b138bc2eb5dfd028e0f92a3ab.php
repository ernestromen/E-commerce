<?php $__env->startSection('main_content'); ?>
<div class="container">
<div class="row">
<div class="col">
<h1>Shopping cart</h1>
<?php if($cart): ?>
<table class="table table-bordered">
<thead>
<tr>
<td>Product</td>
<td class="text-center">Quantity</td>
<td>Price</td>
<td>Sub total</td>
</tr>
</thead>
<tbody>
<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td>
    <img class="img-thumbnail" width="70" src="<?php echo e(asset('images/' . $item['attributes']['image'] )); ?>">
    <span><?php echo e($item['name']); ?></span>
    </td>
<td class="text-center">
<a data-op="minus" data-pid="<?php echo e($item['id']); ?>" class="update-cart-btn" href="#"><i class="fas fa-minus-square"></i></a>
    <input size="1" type="text" value="<?php echo e($item['quantity']); ?>">
    <a data-op="plus" data-pid="<?php echo e($item['id']); ?>" class="update-cart-btn" href="#"><i class="fas fa-plus-square"></i></a>
</td>
<td>$<?php echo e($item['price']); ?></td>
<td>$<?php echo e($item['quantity'] * $item['price']); ?></td>
<td class="text-center">
<a href="<?php echo e(url('shop/remove-item/' . $item['id'])); ?>" class="text-danger remove-item-btn"><i class="fas fa-trash"></i> </a>
</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<p>
    <b>Total:</b>$<?php echo e(Cart::getTotal()); ?>

    <span class="float-right">
    <a href="<?php echo e(url('shop/clear-cart')); ?>" class="btn-btn-light"> Clear Cart</a>
    </span>
</p>
<p>
<a href="<?php echo e(url('shop/order-now')); ?>" class="btn-btn-primary btn-lg">ORDER NOW!</a>
</p>
<?php else: ?>
<p><i>No items in cart!</i></p>
<?php endif; ?>

</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cart.blade.php ENDPATH**/ ?>