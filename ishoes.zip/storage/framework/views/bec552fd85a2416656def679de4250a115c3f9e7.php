<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Categories'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col">
        <p>
        <a href="<?php echo e(url('cms/categories/create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Add Category
            </a>
        </p>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Category Title</th>
                    <th>Category Image</th>
                    <th>Last Update</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($category['ctitle']); ?></td>
                <td><img width="70" src="<?php echo e(asset('images/' . $category['cimage'])); ?>"></td>
                <td><?php echo e(date('d/m/Y', strtotime($category['updated_at']))); ?></td>
                <td>
                <a href="<?php echo e(url('cms/categories/' . $category['id'] . '/edit')); ?>">
                        <i class="far fa-edit"></i>
                        Edit</a>
                        |
                    <a href="<?php echo e(url('cms/categories/' .$category['id'])); ?>">
                            <i class="fas fa-eraser"></i>
                            Delete</a>
                </td>
               
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/categories_index.blade.php ENDPATH**/ ?>