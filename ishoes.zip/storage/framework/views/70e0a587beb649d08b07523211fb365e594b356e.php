<?php $__env->startSection('main_content'); ?>

<div class="container">
    <div class="row">
      <?php if($contents): ?>
      <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <div class="col-12">
    <h3><?php echo e($content->ctitle); ?></h3>
    <p><?php echo $content->article; ?></p>
 </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php else: ?>
      <div class="col-12">
          <p><i>No content avaliable...</i></p>
      </div>
      <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/content.blade.php ENDPATH**/ ?>