<?php $__env->startSection('main_content'); ?>
<div class="container">

    <div class="row" style="background-image: url('background_2.jpg');">
        <div class="col-lg-6">
            <form action="" method="POST" novalidate="novalidate" autocomplete="off">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
                <div class="form-group">
                    <label for="email">* Email</label>
                <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email" class="form-control">
                </div>
                <div class="form-group">
                    <label for="password">* Password</label>
                    <input type="password" name="password" id="password" class="form-control">
                </div>
                <input type="submit" value="Sign In" class="btn-btn-primary" name="submit">
                <?php if( !empty($sign_error) ): ?>
            <span class="text-danger"><?php echo e($sign_error); ?></span>
                <?php endif; ?>
            </form>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/signin.blade.php ENDPATH**/ ?>