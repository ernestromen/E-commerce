<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Edit User'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-8">
    <form action="<?php echo e(url('cms/users/' . $item['id'])); ?>" method="POST" novalidate="novalidate" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

    <input type="hidden" name="item_id" value="<?php echo e($item['id']); ?>">
            <div class="form-group">
                <label for="name">* Name</label>
              
            <input class="form-control origin-text" type="text" name="name" id="name" value="<?php echo e($item['name']); ?>">
            <span class="text-danger"><?php echo e($errors->first('name')); ?></span> 
            </div>
            <div class="form-group">
                <label for="email">* Email</label>
            <input  class="form-control target-text" type="text" name="email" id="email" value="<?php echo e($item['email']); ?>"> 
            <span class="text-danger"><?php echo e($errors->first('email')); ?></span> 
            </div>
             <div class="form-group">
                <label for="kind">*Kind </label>
             <select  class="form-control" name="kind" id="kind">
                 <option value="">choose the type of user..</option>
                 <?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($op->id); ?>"><?php echo e($op->id); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
             <span>*1-Admin, 2-Authenticated User, 3-Content Editor</span>
         
                
            <span class="text-danger"><?php echo e($errors->first('kind')); ?></span>  
            </div> 
           
            <input type="submit" value="Update User" class="btn btn-primary" name="submit">
        <a href="<?php echo e(url('cms/users')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/users_edit.blade.php ENDPATH**/ ?>