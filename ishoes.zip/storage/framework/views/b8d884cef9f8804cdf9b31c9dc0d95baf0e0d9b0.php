<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Edit Content'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-8">
        <form action="<?php echo e(url('cms/content/' . $item['id'])); ?>" method="POST" novalidate="novalidate" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

        <div class="form-group">
            <label for="menu-id">* Menu Link</label>
<select name="menu_id" id="menu-id" class="form-control">
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option <?php if( $item['menu_id']==$menu_item['id'] ): ?> selected="selected" <?php endif; ?> value="<?php echo e($menu_item['id']); ?>"><?php echo e($menu_item['link']); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
            <span class="text-danger"><?php echo e($errors->first('menu_id')); ?></span>
        </div>
            <div class="form-group">
                <label for="title">* Title</label>
            <input class="form-control" type="text" name="title" id="title" value="<?php echo e($item['ctitle']); ?>">
            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
            </div>
            <div class="form-group">
                <label for="article">* Article</label>
                <textarea class="form-control" name="article" id="article" cols="30" rows="10"> <?php echo e($item['article']); ?> </textarea>
                <span class="text-danger"><?php echo e($errors->first('article')); ?></span>
            </div>
            <input type="submit" value="Update Content" class="btn btn-primary" name="submit">
        <a href="<?php echo e(url('cms/content')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/content_edit.blade.php ENDPATH**/ ?>