<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => '+Add new User'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-md-8">
    <form action="<?php echo e(url('cms/users')); ?>" method="POST" novalidate="novalidate" autocomplete="off">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">* Name</label>
        <input value="<?php echo e(old('name')); ?>" type="text" name="name" id="name" class="form-control">
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        </div>
        <div class="form-group">
            <label for="email">* Email</label>
        <input value="<?php echo e(old('email')); ?>" type="email" name="email" id="email" class="form-control">
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        </div>
        <div class="form-group">
            <label for="password">* Password</label>
            <input type="password" name="password" id="password" class="form-control">
            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
        </div>
      
        <div class="form-group">
            <label for="country">* Your country</label>
           <select name="country" id="country" class="form-control">
               <option value="">Choose Country...</option>
               <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <option value="<?php echo e($country->name); ?>"><?php echo e($country->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
        </div>
            <div class="form-group">
                <label for="kind">*Kind </label>
             <select  class="form-control" name="kind" id="kind">
                 <option value="">choose the type of user..</option>
                 <?php $__currentLoopData = $option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($op->id); ?>"><?php echo e($op->id); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </select>
             <span>*1-Admin, 2-Authenticated User, 3-Content Editor</span>
         
                <br>
            <span class="text-danger"><?php echo e($errors->first('kind')); ?></span>  
            </div> 
           
            <input type="submit" value="Save User" class="btn btn-primary" name="submit">
        <a href="<?php echo e(url('cms/users')); ?>" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/users_add.blade.php ENDPATH**/ ?>