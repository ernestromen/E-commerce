<?php $__env->startSection('main_content'); ?>
<div class="container">
<div class="row">
<div class="col">
<h1>welcome the shop categories!</h1>
</div>
</div>
<div class="row">
<?php if($categories): ?>
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-6 col-xl-4">
<div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
          <strong class="d-inline-block mb-2 text-primary">Categorie</strong>
          <h3 class="mb-0"><?php echo e($categorie['ctitle']); ?></h3>
         
          <p class="card-text mb-auto"><?php echo e($categorie['carticle']); ?></p>
          <a href=<?php echo e(url('shop/' . $categorie['curl'])); ?> class="stretched-link">view products</a>
        </div>
        <div class="col-auto d-none d-lg-block">
        <img class="img-fluid image1" src="<?php echo e(asset('images/' . $categorie['cimage'])); ?>">
        </div>
      </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="col">
<p><i>no categorie avaliable</i><p>
</div>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/categories.blade.php ENDPATH**/ ?>