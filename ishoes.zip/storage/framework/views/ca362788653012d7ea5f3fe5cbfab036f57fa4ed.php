<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Products'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col">
        <p>
        <a href="<?php echo e(url('cms/products/create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Add Product
            </a>
        </p>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Product Title</th>
                    <th>Product Image</th>
                    <th>Last Update</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($product['ptitle']); ?></td>
                <td><img width="70" src="<?php echo e(asset('images/' . $product['pimage'])); ?>"></td>
                <td><?php echo e(date('d/m/Y', strtotime($product['updated_at']))); ?></td>
                <td>
                <a href="<?php echo e(url('cms/products/' . $product['id'] . '/edit')); ?>">
                        <i class="far fa-edit"></i>
                        Edit</a>
                        |
                    <a href="<?php echo e(url('cms/products/' .$product['id'])); ?>">
                            <i class="fas fa-eraser"></i>
                            Delete</a>
                </td>
               
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/products_index.blade.php ENDPATH**/ ?>