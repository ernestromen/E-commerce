<?php $__env->startSection('cms_content'); ?>
<?php echo $__env->make('utils.cms_header', ['title' => 'Menu'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col">
        <p>
        <a href="<?php echo e(url('cms/menu/create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Add Menu Link 
            </a>
        </p>
    </div>
</div>
<div class="row">
    <div class="col">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Menu Link</th>
                    <th>Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($menu_item['link']); ?></td>
                <td>
                <a href="<?php echo e(url('cms/menu/' . $menu_item['id'] . '/edit')); ?>">
                        <i class="far fa-edit"></i>
                        Edit</a>
                        |
                    <a href="<?php echo e(url('cms/menu/' .$menu_item['id'])); ?>">
                            <i class="fas fa-eraser"></i>
                            Delete</a>
                </td>
               
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ishoes\resources\views/cms/menu_index.blade.php ENDPATH**/ ?>